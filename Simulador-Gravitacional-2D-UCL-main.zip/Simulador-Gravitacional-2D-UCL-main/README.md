# Simulador-Gravitacional-2D-UCL
Simulador gravitacional que atravéz de calculos fisicos simula o movimento das particulas,  calcula trajetoria e colisão das mesma, trabalho da Faculdade UCL da disciplina de  programação avançada de sistemas.
